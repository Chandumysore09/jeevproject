import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './myfolder/login/login.component';
import { SignUpComponent } from './myfolder/sign-up/sign-up.component';
import {DashboardComponent} from './myfolder/dashboard/dashboard.component';
import {MainpageComponent} from './myfolder/mainpage/mainpage.component';
import {AdminloginComponent } from './myfolder/adminlogin/adminlogin.component';
import {HeaderComponent } from './myfolder/header/header.component';
import {UserdashboardComponent} from './myfolder/userdashboard/userdashboard.component';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'sign',
    component: SignUpComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: 'Main',
    component: MainpageComponent
  },
  {
    path: 'Admin',
    component: AdminloginComponent 
  },
  {
    path: 'head',
    component: HeaderComponent
  },
  {
    path: 'userdashboard',
    component: UserdashboardComponent
    
  },
  
  // Consider removing the route for AppComponent unless there's a specific reason for it
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
