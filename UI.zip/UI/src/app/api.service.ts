// api.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';



const apiUrl = 'http://localhost:8081';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  

  constructor(private http: HttpClient) {
    
  }

  // Sign up Page
  signUp(user: any): Observable<any> {
    return this.http.post(apiUrl + '/auth/employees', user).pipe(
      map((response) => {
        console.log('Registration successful:', response);
        return response; // You might return the response if needed
      }),
      catchError((error) => {
        console.error('Error occurred during registration:', error);
        return throwError(error);
      })
    );
  }

  // Login page
  login(login: any): Observable<any> {
    return this.http.post(apiUrl + '/auth/loginBy', login).pipe(
      map((response: any) => {
        
        
        return response;
      }),
      catchError((error) => {
        console.error('Error occurred during login:', error);
        return throwError(error);
      })
    );
  }

  save(login: any, user: any): Observable<any> {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${login}`);
  
    return this.http.put(apiUrl + '/auth/updateEmployee', user, { headers }).pipe(
      map((response: any) => {
        console.log(response)
        return response;
      }),
      catchError((error) => {
        console.error('Error occurred during login:', error);
        return throwError(error);
      })
    );
    
  }
  


  


  delet(token: any, user: any): Observable<any> {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    const options = { headers };
  
    console.log(user);
  
    return this.http.delete(`${apiUrl}/auth/delete?employ_id=${user}`, options).pipe(
      map((response: any) => {
        return response;
      }),
      catchError((error) => {
        console.error('Error occurred during delete:', error);
        return throwError(error);
      })
    );
  }
  

  auto(login: any,): Observable<any> {

    // Setting up the Authorization header with the provided bearer token
    const headers = new HttpHeaders().set('Authorization', `Bearer ${login}`);

    // Making an HTTP GET request to the specified API endpoint with the headers
    return this.http.get(apiUrl + '/auth/getAllEmployee', { headers }).pipe(
      // Mapping the response
      map((response: any) => {
        return response;
      }),
      // Handling errors
      catchError((error) => {
        console.error('Error occurred during login:', error);
        return throwError(error);
      })
    );
}

Admin(login: any)
{
  return this.http.post(apiUrl + '/auth/AdminBy', login).pipe(
    map((response: any) => {
      
      
      return response;
    }),
    catchError((error) => {
      console.error('Error occurred during login:', error);
      return throwError(error);
    })
  );
}
}
