import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './myfolder/login/login.component';
import { SignUpComponent } from './myfolder/sign-up/sign-up.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; // Import both FormsModule and ReactiveFormsModule
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule ,HTTP_INTERCEPTORS} from '@angular/common/http';
import { DashboardComponent } from './myfolder/dashboard/dashboard.component';
import { MainpageComponent } from './myfolder/mainpage/mainpage.component';

import {HeaderComponent } from './myfolder/header/header.component';
import {EmploginComponent } from'./myfolder/emplogin/emplogin.component';
import { AdminloginComponent } from './myfolder/adminlogin/adminlogin.component';
import { UserdashboardComponent } from './myfolder/userdashboard/userdashboard.component';
import { FooterComponent } from './myfolder/footer/footer.component';
import { NavbarComponent } from './myfolder/navbar/navbar.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignUpComponent,
    DashboardComponent,
    MainpageComponent,
    HeaderComponent,
    EmploginComponent,
    AdminloginComponent,
    UserdashboardComponent,
    FooterComponent,
    NavbarComponent,
    
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,         // Add this line
    ReactiveFormsModule, // Add this line
    NgbModule,
    HttpClientModule
    
    // other modules
  ],
  providers: [  ],
  bootstrap: [AppComponent],
  
})
export class AppModule { }

