import { ApiService } from '../../api.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router,NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  LoginempForm!: FormGroup;
  errorMessage: string = '';  // Add a variable to store the error message

  constructor(private apiservice: ApiService, private formBuilder: FormBuilder, private route: Router) { }

 

  ngOnInit() {
    this.LoginempForm = this.formBuilder.group({
      mail_id: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }



  login() {
    console.log(this.LoginempForm.value);
    this.apiservice.login(this.LoginempForm.value).subscribe(
      (res: any) => {

        localStorage.setItem('Username', this.LoginempForm.get('mail_id')?.value);
        localStorage.setItem('authtoken', res.jwtToken);
        console.log('authtoken:', res.jwtToken);
        console.log( res.status);
          
        if (this.LoginempForm) {
         
          
         
          if(res.status==1)
            this.route.navigateByUrl('userdashboard');
          else
          this.route.navigateByUrl('dashboard');
            
        }
      },
      (error) => {
        console.error('Login error:', error);
        this.errorMessage = 'Invalid Credentials'; 
        setTimeout(() => {
          this.errorMessage = '';
        }, 4000);// Set error message
      }
    );
  }

  resetForm() {
    this.LoginempForm.reset();
    this.errorMessage = ''; // Clear error message when resetting the form
  }


  message()
  {
    this.errorMessage = 'Contact Admin';
    setTimeout(() => {
      this.errorMessage = '';
    }, 4000);

  }
}
