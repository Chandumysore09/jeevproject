import { Component, OnInit } from '@angular/core';
import {  FormGroup } from '@angular/forms';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  tableData: any[] = [];
  editRowIndex: number | null = null;
  editMode: { [key: string]: boolean } = {};
  data!:number;
  errorMessage: string = '';
  success:string = '';
  

  constructor(private apiservice: ApiService, private router: Router) { }

  ngOnInit() {
    // Call the auto method to fetch data and update the tableData
    this.auto();
  }

  edit(item: any) {
    
    this.tableData.forEach(element => {
      element.isEdit = false;
    });
    item.isEdit = true;
  }



  save(employeeId: number, mail: string, phone: number, location: string, team: string) {
    const authtoken = localStorage.getItem('authtoken');
  
    const editedRow = {
      employ_id: employeeId,
      mail_id: mail,
      phone_no: phone,
      location: location,
      team: team
    };
  
    if (!mail || !phone || !location || !team) {
      this.errorMessage = 'Invalid input data. All fields are required. Data NOT Saved.';
      setTimeout(() => {
        this.errorMessage = '';
      }, 4000);
      return;
    } else if (!/^\d{10}$/.test(phone.toString())) {
      this.errorMessage = 'Invalid phone number. Please enter 10 digits. Data NOT Saved.';
      setTimeout(() => {
        this.errorMessage = '';
      }, 4000);
      return;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) {
      this.errorMessage = 'Invalid email address. Data NOT Saved.';
      setTimeout(() => {
        this.errorMessage = '';
      }, 4000);
      return;
    }

    console.log('Values to be saved:', editedRow);

    this.apiservice.save(authtoken, editedRow)
      .subscribe(
        (res: any) => {
          console.log(res);
          const index = this.tableData.findIndex(row => row.employ_id === employeeId);
          if (index !== -1) {
            this.tableData[index].isEdit = false;
            this.editRowIndex = null;
          }

          if (res.message === 'Employee updated successfully') {
            console.log('Successfully updated:', editedRow);
            this.success = 'Successfully updated';

            // Clear success message after 2 seconds
            setTimeout(() => {
              this.success = '';
            }, 2000);
          }
        },
        (error) => {
          console.error('Error occurred during save:', error);
          this.errorMessage = 'Error occurred during save. Data NOT Saved.';
          setTimeout(() => {
            this.errorMessage = '';
          }, 4000);
        }
      );
  }

  
  

  delet() {
    console.log(this.data);
    const authtoken = localStorage.getItem('authtoken');
    
    this.apiservice.delet(authtoken, this.data)
      .subscribe(
        () => {
          // Reset editRowIndex after successful delete
          this.editRowIndex = null;
          this.auto();
        },
        (error) => {
          // Handle errors here, e.g., show a message to the user
          console.error('Error occurred during delete:', error);
        }
      );

     this.hideDeleteModal();
}


  auto() {
    const authtoken = localStorage.getItem('authtoken');

    if (authtoken) {
      this.apiservice.auto(authtoken)
        .pipe(
          catchError((error) => {
            console.error('Error occurred during auto:', error);
            // You can handle errors here, e.g., show a message to the user
            return throwError(error);
          })
        )
        .subscribe((res: any) => {
          // Handle the auto response accordingly
          console.log('Auto Response:', res);

          // Add editMode property to each row for each field
          this.tableData = res.map((row: any) => ({ ...row, editMode: false }));
        });
    } else {
      console.error('No authtoken found in localStorage.');
    }
  }

  logout() {
    // Remove token from local storage
    localStorage.removeItem('token');

    // Redirect to login page
    this.router.navigateByUrl('login');
  }



  showDeleteModal(index:any) {
    const modal = document.getElementById('deleteModal');
    if (modal) {
      modal.style.display = 'block';
      this.data= index;
      
    }
  }

  hideDeleteModal() {
    const modal = document.getElementById('deleteModal');
    if (modal) {
      modal.style.display = 'none';
    }
  }



  cancelDelete() {
    // Cancel delete, close the modal
    this.hideDeleteModal();
  }
}
