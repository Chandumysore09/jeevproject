import { ApiService } from '../../api.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  LoginempForm!: FormGroup; 

  constructor(private apiservice: ApiService, private formBuilder: FormBuilder, private route: Router) { }

  ngOnInit() {
    this.LoginempForm = this.formBuilder.group({
      mail_id: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  login() {
    console.log(this.LoginempForm.value);
    this.apiservice.login(this.LoginempForm.value).subscribe((res: any) => {
      localStorage.setItem('token', res.jwtToken);
      console.log('token:', res.jwtToken);
      this.route.navigateByUrl('dashboard');
    });
  }

}
