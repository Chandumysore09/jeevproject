import { ApiService } from '../../api.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';




@Component({
  selector: 'app-emplogin',
  templateUrl: './emplogin.component.html',
  styleUrls: ['./emplogin.component.css']
})

export class EmploginComponent implements OnInit {
  
  LoginForm!: FormGroup; 

  constructor(private apiservice: ApiService, private formBuilder: FormBuilder, private route: Router) { }

  ngOnInit() {
    this.LoginForm = this.formBuilder.group({
      mail_id: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  login() {
    console.log(this.LoginForm.value);
    this.apiservice.login(this.LoginForm.value).subscribe((res: any) => {
      localStorage.setItem('authtoken', res.jwtToken);
      console.log('authtoken:', res.jwtToken);
      this.route.navigateByUrl('dashboard');
    });
  }
}
