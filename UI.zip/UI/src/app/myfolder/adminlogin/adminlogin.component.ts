import { ApiService } from '../../api.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrl: './adminlogin.component.css'
})
export class AdminloginComponent implements OnInit{
  LoginForm!: FormGroup; 
  errorMessage: string = ''; 

  constructor(private apiservice: ApiService, private formBuilder: FormBuilder, private route: Router) { }

  ngOnInit() {
    this.LoginForm = this.formBuilder.group({
      mail_id: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  Admin() {
    console.log(this.LoginForm.value);
    this.apiservice.login(this.LoginForm.value).subscribe(
      (res: any) => {
        localStorage.setItem('token', res.jwtToken);
        console.log('token:', res.jwtToken);
        this.route.navigateByUrl('dashboard');
      },
      (error) => {
        console.error('Login error:', error);
        this.errorMessage = 'Invalid Credentials'; 
        setTimeout(() => {
          this.errorMessage = '';
        }, 3000);// Set error message
      }
    );
  }

  
  resetForm() {
    this.LoginForm.reset();
    this.errorMessage = ''; // Clear error message when resetting the form
  }

}
