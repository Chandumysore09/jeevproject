import { ApiService } from '../../api.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  postCustomerForm!: FormGroup;
  errorMessage: string = '';
  errorMessageEmail: string = '';
  errorMessagePhone: string = '';

  constructor(private apiservice: ApiService, private formBuilder: FormBuilder, private route: Router) { }

  ngOnInit() {
    this.postCustomerForm = this.formBuilder.group({
      employeeName: ['', Validators.required],
      mail_id: ['', [Validators.required, Validators.email]],
      location: ['', Validators.required],
      phone_no: ['', [Validators.required, Validators.pattern('[0-9]{10}')]],
      team: ['', Validators.required],
      password: ['', Validators.required],
      repeat_password: ['', Validators.required],
    }, { validator: this.passwordMatchValidator });
  }

  passwordMatchValidator(control: AbstractControl): { passwordMismatch: boolean } | null {
    const password = control.get('password')?.value;
    const repeatPassword = control.get('repeat_password')?.value;

    if (password !== repeatPassword) {
      return { passwordMismatch: true };
    } else {
      return null;
    }
  }

  sign() {
    console.log(this.postCustomerForm.value);
    this.apiservice.signUp(this.postCustomerForm.value).subscribe((res) => {
      console.log(res);
      this.route.navigateByUrl('login');
    });
  }

  validate() {
    if (this.postCustomerForm.valid) {
      console.log(this.postCustomerForm.value);
      this.sign();
    } else {
      if (this.postCustomerForm.get('phone_no')?.hasError('pattern')) {
        this.errorMessagePhone = 'Invalid phone number. Please enter 10 digits.';
        setTimeout(() => {
          this.errorMessagePhone = '';
        }, 3000);
      }

      if (this.postCustomerForm.get('mail_id')?.hasError('email')) {
        this.errorMessageEmail = 'Invalid email address.';
        setTimeout(() => {
          this.errorMessageEmail = '';
        }, 3000);
      }

      if (this.postCustomerForm.get('password')?.value !== this.postCustomerForm.get('repeat_password')?.value) {
        this.errorMessage = 'Please Check Password.';
        setTimeout(() => {
          this.errorMessage = '';
        }, 3000);
      }
    }
  }
}
