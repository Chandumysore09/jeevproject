package sample.demo.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class AwtResponse {

    private  String  AwtToken;

    private  String  employeeName;
}
