package sample.demo.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class AwtRequest {

    private int employ_id;
    private String employeeName;
    private String team;
    private String location;
    private int status ;
    private String mail_id;
    private long phone_no;
    private String password;
}
