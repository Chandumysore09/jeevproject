package sample.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import sample.demo.DTO.AdminDTO;
import sample.demo.DTO.EmployeeDTO;
import sample.demo.entity.Employee;

import java.util.List;
import java.util.Optional;

public interface userinterface extends JpaRepository<Employee,Integer> {

    @Query("from Employee where employ_id = :emp1")
    Employee getEmployId(int emp1);

    @Query(value = "select new sample.demo.DTO.EmployeeDTO(e.employ_id ,e.employeeName,e.location,e.mail_id,e.phone_no,e.team) " +
            " from Employee e where status != 2")
    List<EmployeeDTO> getEmployee();


    @Query("from Employee where mail_id = :mailId")
    Optional<Employee> findByMailId(String mailId);

    @Transactional
    @Modifying
    @Query(value = "delete from employee e where e.employ_id = :employ_id", nativeQuery = true)
    void deleteEmployee(int employ_id);






    @Query(value = "update employee e set e.team = :#{#employee.team}, e.mail_id = :#{#employee.mail_id}, e.location = :#{#employee.location}, e.phone_no = :#{#employee.phone_no} where e.employ_id = :#{#employee.employ_id}", nativeQuery = true)
    @Modifying
    @Transactional
    void updateEmployee(@Param("employee") Employee employee);



    @Query("SELECT new sample.demo.DTO.AdminDTO(e.status) FROM Employee e WHERE e.mail_id = :mailId and e.status=2")
    AdminDTO FindAdmin(@Param("mailId") String mailId);


    @Query("SELECT new sample.demo.DTO.AdminDTO(e.status) FROM Employee e WHERE e.mail_id = :mailId ")
    AdminDTO FindStatus(String mailId);
}


