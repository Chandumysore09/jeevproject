package sample.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;
import sample.demo.DTO.EmployeeDTO;
import sample.demo.entity.Employee;
import sample.demo.model.AwtRequest;
import sample.demo.model.AwtResponse;
import sample.demo.model.JwtRequest;
import sample.demo.model.JwtResponse;
import sample.demo.security.JwtHelper;
import sample.demo.services.services;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/auth")
@CrossOrigin("*")
public class controller
{

    @Autowired
    private JwtHelper helper;

    private Logger logger = LoggerFactory.getLogger(controller.class);


     @Autowired
     private services services;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private AuthenticationManager manager;


    @GetMapping("/emp1")
    public Employee getEmployee(int employId) {

        return services.getEmployeeById(employId);
    }

    @GetMapping("/getAllEmployee")
    public List<EmployeeDTO> getAllEmployee() {
        return services.getAllEmployees();
    }

    @PutMapping("/updateEmployee")
    public HashMap<String ,String> updateEmployee(@RequestBody Employee newEmployee) {
        System.out.println("controller");
        services.updateEmployee(newEmployee);
        HashMap<String ,String> response=  new HashMap<>();
        response.put("message", "Employee updated successfully");


        return response;
    }


    @PostMapping("/employees")
    public Employee createEmployee(@RequestBody Employee newEmployees)
    {
        return services.createEmployee(newEmployees);
    }


    @DeleteMapping("/delete")
    public ResponseEntity<?> deleteEmployee(@RequestParam(name = "employ_id") Optional<Integer> employIdOptional) {
        System.out.println("controller");

        if (employIdOptional.isPresent()) {
            Integer employId = employIdOptional.get();
            services.deleteEmployee(employId);
            return ResponseEntity.ok().build(); // Assuming a successful response
        } else {
            return ResponseEntity.badRequest().body("employ_id is required"); // Handle the case where employ_id is not provided
        }
    }
    @PostMapping("/AdminBy")
    public ResponseEntity<AwtResponse> login(@RequestBody AwtRequest request) {

        AwtResponse response = null;
        if (services.FindAdmin(request.getMail_id())) {
            System.out.println(request.getMail_id() + request.getPassword());

            this.doAuthenticate(request.getMail_id(), request.getPassword());
            String s = request.getMail_id();


            UserDetails userDetails = userDetailsService.loadUserByUsername(request.getMail_id());
            String token = this.helper.generateToken(userDetails);

            response = AwtResponse.builder().AwtToken(token)
                    .employeeName(userDetails.getUsername()).build();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }


    }

   @PostMapping("/loginBy")
   public ResponseEntity<JwtResponse> login(@RequestBody JwtRequest request)
   {

           int Result = services.FindStatus(request.getMail_id());

            System.out.println(request.getMail_id() + request.getPassword());

            this.doAuthenticate(request.getMail_id(), request.getPassword());
            String s = request.getMail_id();


            UserDetails userDetails = userDetailsService.loadUserByUsername(request.getMail_id());
            String token = this.helper.generateToken(userDetails);


       JwtResponse response;
       if(Result == 2) {

           response = JwtResponse.builder().jwtToken(token)
                   .employeeName(userDetails.getUsername()).status(2).build();

       }
        else {
           response = JwtResponse.builder().jwtToken(token)
                   .employeeName(userDetails.getUsername()).status(1).build();
       }
       return new ResponseEntity<>(response, HttpStatus.OK);


   }

    private void doAuthenticate(String mail_id, String password) {

            UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(mail_id, password);
            try {


                 manager.authenticate(authentication);




            } catch (BadCredentialsException e) {
                throw new BadCredentialsException(" Invalid Username or Password  !!");
            }

    }
    @ExceptionHandler(BadCredentialsException.class)
    public String exceptionHandler()
        {
            return "Credentials Invalid !!";
        }




}
