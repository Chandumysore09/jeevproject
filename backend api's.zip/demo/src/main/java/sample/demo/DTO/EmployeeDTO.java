package sample.demo.DTO;

import lombok.Data;

@Data
    public class EmployeeDTO {
        private int employId;
        private String employeeName;
        private String location;
        private String mailId;
        private Long phoneNo;
        private String team;


        // Constructors, getters, setters

    public EmployeeDTO(int employId, String employeeName, String location, String mailId, Long phoneNo, String team) {
        this.employId = employId;
        this.employeeName = employeeName;
        this.location = location;
        this.mailId = mailId;
        this.phoneNo = phoneNo;
        this.team = team;

    }
}


