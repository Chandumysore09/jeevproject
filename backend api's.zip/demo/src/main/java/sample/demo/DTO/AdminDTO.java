package sample.demo.DTO;


import lombok.Data;

@Data
public class AdminDTO {

    private int status;

    public AdminDTO(int status) {
        this.status = status;
    }


}
