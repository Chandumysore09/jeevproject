package sample.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import sample.demo.DTO.AdminDTO;
import sample.demo.DTO.EmployeeDTO;
import sample.demo.entity.Employee;

import java.util.List;

@Service
public class services {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private sample.demo.repository.userinterface userinterface;

    public List<Employee> getEmployee(){
         return userinterface.findAll();

    }
    public Employee createEmployee(Employee employee)
    {

         employee.setPassword(passwordEncoder.encode(employee.getPassword()));
        return userinterface.save(employee);
    }


    public Employee getEmployeeById(int employId) {
        return userinterface.getEmployId(employId);
    }

    public List<EmployeeDTO> getAllEmployees() {
        return userinterface.getEmployee();
    }

    public void updateEmployee(Employee employee) {
        userinterface.updateEmployee(employee);
    }


    public void deleteEmployee(int employ_id) {
        System.out.println("services");
         userinterface.deleteEmployee(employ_id);
    }


    public boolean FindAdmin(String mailId) {

       AdminDTO adminDTO = userinterface.FindAdmin(mailId);
       if(adminDTO != null)
       {
           return true;
       }
       else
           return false;

    }

    public int FindStatus(String mailId) {
        AdminDTO adminDTO =  userinterface.FindStatus(mailId);
        return adminDTO.getStatus() ;

    }
}
